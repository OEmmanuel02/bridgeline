import {
  lazy,
  Suspense,
  useEffect,
  useState,
  type FormEvent,
  type ReactNode,
} from 'react'
import {
  BrowserRouter,
  Link,
  Navigate,
  Route,
  Routes,
  useLocation,
  useNavigate,
  useSearchParams,
} from 'react-router-dom'
import {
  validateCandidateApplication,
  validateContactMessage,
  validateHiringRequest,
  type CandidateApplicationValues,
  type ContactMessageValues,
  type FormErrors,
  type HiringRequestValues,
} from './lib/formValidation'
import {
  ApiRequestError,
  publicRegistrationEnabled,
  publicSubmissionsEnabled,
  submitPublicForm,
} from './lib/api'
import { SessionProvider } from './lib/session-provider'
import { useSession } from './lib/useSession'
import './App.css'

const DashboardPage = lazy(() =>
  import('./pages/DashboardPage').then((module) => ({ default: module.DashboardPage })),
)

const currentYear = new Date().getFullYear()

const navigation = [
  { label: 'Home', href: '/' },
  { label: 'For candidates', href: '/candidates' },
  { label: 'For employers', href: '/employers' },
  { label: 'About', href: '/about' },
  { label: 'Contact', href: '/contact' },
]

const roles = [
  {
    number: '01',
    title: 'Customer support',
    description: 'Help customers get clear, thoughtful answers and a dependable experience.',
  },
  {
    number: '02',
    title: 'Virtual assistance',
    description: 'Support busy teams with the coordination and follow-through that keeps work moving.',
  },
  {
    number: '03',
    title: 'Operations support',
    description: 'Bring care and consistency to the everyday processes behind a growing business.',
  },
]

const questions = [
  {
    question: 'Is it free to apply?',
    answer:
      'Yes. Candidates never pay an application fee. Bridgeline’s business model is based on employer-paid placement fees.',
  },
  {
    question: 'Who is the program for?',
    answer:
      'Bridgeline is being built for ambitious Nigerians interested in developing the skills needed for remote work. Specific eligibility requirements will be shared when applications open.',
  },
  {
    question: 'What roles does Bridgeline focus on?',
    answer:
      'The initial focus areas are customer support, virtual assistance, and operations support. A role focus does not mean there is an active vacancy.',
  },
  {
    question: 'How does training work?',
    answer:
      'Candidates who progress will receive structured training and assessment. The curriculum and schedule have not yet been established; confirmed details should be available before applications open.',
  },
  {
    question: 'Does completing training guarantee a job?',
    answer:
      'No. Training does not guarantee placement. Opportunities depend on assessment results, employer requirements, and available positions.',
  },
  {
    question: 'How are candidates matched with employers?',
    answer:
      'Candidates are considered for employer matching after training and assessment. Employers only see candidate information when Bridgeline authorizes access.',
  },
]

function ArrowIcon({ diagonal = false }: { diagonal?: boolean }) {
  return (
    <svg
      aria-hidden="true"
      className={diagonal ? 'arrow-icon arrow-icon--diagonal' : 'arrow-icon'}
      viewBox="0 0 20 20"
      fill="none"
    >
      <path d="M3.5 10h12m-5-5 5 5-5 5" />
    </svg>
  )
}

function Wordmark({ light = false }: { light?: boolean }) {
  return (
    <Link
      aria-label="Bridgeline home"
      className={`wordmark${light ? ' wordmark--light' : ''}`}
      to="/"
    >
      <span className="wordmark__symbol" aria-hidden="true">
        <span />
        <span />
        <span />
      </span>
      <span>bridgeline</span>
    </Link>
  )
}

function Header() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(() => window.scrollY > 24)
  const { user } = useSession()

  useEffect(() => {
    const updateScroll = () => setScrolled(window.scrollY > 24)
    window.addEventListener('scroll', updateScroll, { passive: true })
    return () => window.removeEventListener('scroll', updateScroll)
  }, [])

  return (
    <header className={`site-header${scrolled ? ' site-header--scrolled' : ''}`}>
      <div className="site-header__inner">
        <Wordmark light />
        <button
          aria-controls="primary-navigation"
          aria-expanded={menuOpen}
          aria-label={menuOpen ? 'Close navigation menu' : 'Open navigation menu'}
          className={`menu-toggle${menuOpen ? ' menu-toggle--open' : ''}`}
          onClick={() => setMenuOpen((open) => !open)}
          type="button"
        >
          <span />
          <span />
        </button>
        <nav
          aria-label="Main navigation"
          className={`primary-navigation${menuOpen ? ' primary-navigation--open' : ''}`}
          id="primary-navigation"
        >
          <div className="primary-navigation__links">
            {navigation.map((item) => (
              <Link key={item.href} onClick={() => setMenuOpen(false)} to={item.href}>
                {item.label}
              </Link>
            ))}
          </div>
          <Link
            className="primary-navigation__signin"
            onClick={() => setMenuOpen(false)}
            to={user ? '/account' : '/login'}
          >
            {user ? 'My account' : 'Sign in'}
          </Link>
          <Link
            className="button button--small button--gold"
            onClick={() => setMenuOpen(false)}
            to="/candidates"
          >
            Apply as a candidate <ArrowIcon diagonal />
          </Link>
        </nav>
      </div>
    </header>
  )
}

function Eyebrow({ children, light = false }: { children: ReactNode; light?: boolean }) {
  return <p className={`eyebrow${light ? ' eyebrow--light' : ''}`}>{children}</p>
}

function SectionHeading({
  eyebrow,
  title,
  children,
  light = false,
}: {
  eyebrow: string
  title: string
  children?: string
  light?: boolean
}) {
  return (
    <div className={`section-heading${light ? ' section-heading--light' : ''}`}>
      <Eyebrow light={light}>{eyebrow}</Eyebrow>
      <h2>{title}</h2>
      {children && <p className="section-heading__copy">{children}</p>}
    </div>
  )
}

function HomePage() {
  useEffect(() => {
    const revealElements = document.querySelectorAll<HTMLElement>('[data-reveal]')
    if (
      !('IntersectionObserver' in window) ||
      window.matchMedia('(prefers-reduced-motion: reduce)').matches
    ) {
      revealElements.forEach((element) => element.classList.add('is-visible'))
      return
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible')
            observer.unobserve(entry.target)
          }
        })
      },
      { threshold: 0.14 },
    )
    revealElements.forEach((element) => {
      observer.observe(element)
    })
    return () => observer.disconnect()
  }, [])

  return (
    <>
      <a className="skip-link" href="#main-content">
        Skip to main content
      </a>
      <Header />
      <main id="main-content">
        <section className="hero">
          <div aria-hidden="true" className="hero__grid" />
          <div aria-hidden="true" className="hero-art">
            <div className="hero-art__halo hero-art__halo--outer" />
            <div className="hero-art__halo hero-art__halo--inner" />
            <div className="hero-art__sun" />
            <div className="hero-art__bridge">
              <span className="hero-art__bridge-top" />
              <span className="hero-art__bridge-deck" />
              <span className="hero-art__pillar hero-art__pillar--left" />
              <span className="hero-art__pillar hero-art__pillar--right" />
              <span className="hero-art__reflection" />
            </div>
            <span className="hero-art__coordinate hero-art__coordinate--left">
              06° 31&apos; N
            </span>
            <span className="hero-art__coordinate hero-art__coordinate--right">
              03° 22&apos; E
            </span>
          </div>
          <div className="hero__content content-width">
            <Eyebrow light>Built for what comes next</Eyebrow>
            <h1>
              Local talent.
              <br />
              <span>Global opportunity.</span>
            </h1>
            <p className="hero__description">
              We train ambitious Nigerians for remote work and connect qualified talent with
              companies around the world.
            </p>
            <div className="hero__actions">
              <Link className="button button--gold" to="/candidates">
                Start your journey <ArrowIcon diagonal />
              </Link>
              <a className="text-link text-link--light" href="#employers">
                I&apos;m hiring <ArrowIcon />
              </a>
            </div>
            <p className="hero__note">No application fee. No promise of guaranteed employment.</p>
          </div>
          <a className="hero__scroll" href="#approach">
            <span className="hero__scroll-line" />
            <span>Scroll to discover</span>
          </a>
          <span aria-hidden="true" className="hero__index">
            01 — 05
          </span>
        </section>

        <section aria-label="Our approach" className="principles-strip" id="approach">
          <div className="content-width principles-strip__inner">
            <p>Opportunity should be earned, not bought.</p>
            <div className="principles-strip__items">
              <span>Training</span>
              <span aria-hidden="true">/</span>
              <span>Assessment</span>
              <span aria-hidden="true">/</span>
              <span>Matching</span>
            </div>
          </div>
        </section>

        <section className="story-section section-pad">
          <div className="content-width story-section__grid">
            <div className="story-section__visual reveal" data-reveal>
              <div aria-hidden="true" className="story-art">
                <div className="story-art__line story-art__line--one" />
                <div className="story-art__line story-art__line--two" />
                <div className="story-art__line story-art__line--three" />
                <span className="story-art__label">A bridge to possibility</span>
                <span className="story-art__number">01 / 03</span>
                <div className="story-art__mark">
                  <span />
                  <span />
                  <span />
                </div>
              </div>
            </div>
            <div className="story-section__copy reveal" data-reveal>
              <SectionHeading eyebrow="The opportunity" title="Potential is everywhere. Access isn’t.">
                Talented people are ready to contribute. Businesses need dependable support. The
                right preparation can bring the two closer together.
              </SectionHeading>
              <div className="story-section__statement">
                <span className="statement-mark">“</span>
                <p>
                  Bridgeline creates a clearer path from <em>ambition</em> to <em>opportunity.</em>
                </p>
              </div>
              <Link className="text-link" to="/about">
                Get to know Bridgeline <ArrowIcon />
              </Link>
            </div>
          </div>
        </section>

        <section className="process-section section-pad">
          <div className="content-width">
            <div className="process-section__intro reveal" data-reveal>
              <SectionHeading eyebrow="A thoughtful process" title="Prepared with purpose.">
                A considered journey helps candidates build relevant skills and helps employers
                make more informed decisions.
              </SectionHeading>
              <span className="process-section__aside">A path forward, together</span>
            </div>
            <div className="journeys">
              <article className="journey-card journey-card--candidate reveal" data-reveal>
                <div className="journey-card__topline">
                  <span>01</span>
                  <span>For candidates</span>
                </div>
                <h3>Your next chapter starts here.</h3>
                <ol className="step-list">
                  <li>
                    <span>01</span>
                    <div>
                      <h4>Apply</h4>
                      <p>Tell us where you want to go and what you bring.</p>
                    </div>
                  </li>
                  <li>
                    <span>02</span>
                    <div>
                      <h4>Learn &amp; demonstrate</h4>
                      <p>Build relevant skills and show what you can do.</p>
                    </div>
                  </li>
                  <li>
                    <span>03</span>
                    <div>
                      <h4>Become match-ready</h4>
                      <p>Qualifying candidates may be considered for employer matching.</p>
                    </div>
                  </li>
                </ol>
                <Link className="text-link" to="/candidates">
                  Explore the candidate journey <ArrowIcon />
                </Link>
              </article>
              <article className="journey-card journey-card--employer reveal" data-reveal>
                <div className="journey-card__topline">
                  <span>02</span>
                  <span>For employers</span>
                </div>
                <h3>Find people ready to contribute.</h3>
                <ol className="step-list">
                  <li>
                    <span>01</span>
                    <div>
                      <h4>Share your needs</h4>
                      <p>Tell us about the role and the support your team needs.</p>
                    </div>
                  </li>
                  <li>
                    <span>02</span>
                    <div>
                      <h4>We identify &amp; assess</h4>
                      <p>We look for relevant skills and role alignment.</p>
                    </div>
                  </li>
                  <li>
                    <span>03</span>
                    <div>
                      <h4>Meet eligible talent</h4>
                      <p>Review suitable candidates when matching is authorized.</p>
                    </div>
                  </li>
                </ol>
                <Link className="text-link" to="/employers">
                  Explore hiring with Bridgeline <ArrowIcon />
                </Link>
              </article>
            </div>
          </div>
        </section>

        <section className="roles-section section-pad">
          <div className="content-width">
            <div className="roles-section__heading reveal" data-reveal>
              <SectionHeading eyebrow="Where we begin" title="Skills for work that matters.">
                Our initial focus is on practical roles that help remote teams do their best work.
              </SectionHeading>
              <span className="roles-section__note">Initial areas of focus</span>
            </div>
            <div className="role-list">
              {roles.map((role) => (
                <article className="role-item reveal" data-reveal key={role.number}>
                  <span className="role-item__number">{role.number}</span>
                  <h3>{role.title}</h3>
                  <p>{role.description}</p>
                  <span aria-hidden="true" className="role-item__ornament">
                    <span />
                    <span />
                    <span />
                  </span>
                </article>
              ))}
            </div>
            <p className="roles-section__disclaimer">
              Focus areas are not a guarantee of current vacancies or future placement.
            </p>
          </div>
        </section>

        <section className="employer-section section-pad" id="employers">
          <div className="content-width employer-section__grid">
            <div className="employer-section__copy reveal" data-reveal>
              <Eyebrow light>For the teams building what’s next</Eyebrow>
              <h2>Good work deserves good people.</h2>
              <p>
                Bridgeline helps employers connect with Nigerian talent prepared for remote
                customer support, virtual assistance, and operations roles.
              </p>
              <ul className="check-list">
                <li>Role-relevant training and assessment</li>
                <li>Candidate visibility managed with care</li>
                <li>A considered path from request to introduction</li>
              </ul>
              <Link className="button button--outline-light" to="/employers">
                Hire through Bridgeline <ArrowIcon diagonal />
              </Link>
            </div>
            <div aria-hidden="true" className="employer-visual reveal" data-reveal>
              <span className="employer-visual__caption">Different places. Shared ambition.</span>
              <div className="employer-visual__orbit employer-visual__orbit--one" />
              <div className="employer-visual__orbit employer-visual__orbit--two" />
              <div className="employer-visual__orbit employer-visual__orbit--three" />
              <span className="employer-visual__point employer-visual__point--one" />
              <span className="employer-visual__point employer-visual__point--two" />
              <span className="employer-visual__point employer-visual__point--three" />
              <div className="employer-visual__center">B</div>
              <span className="employer-visual__label employer-visual__label--one">Lagos</span>
              <span className="employer-visual__label employer-visual__label--two">Your team</span>
            </div>
          </div>
        </section>

        <section className="candidate-section section-pad" id="candidates">
          <div className="content-width candidate-section__grid">
            <div className="candidate-section__heading reveal" data-reveal>
              <SectionHeading eyebrow="For candidates" title="Your ambition has a place here.">
                Build practical skills for a changing world of work—and take your next step with
                intention.
              </SectionHeading>
              <Link className="button button--dark" to="/candidates">
                Apply for free <ArrowIcon diagonal />
              </Link>
            </div>
            <div className="candidate-points reveal" data-reveal>
              <div className="candidate-point">
                <span>01</span>
                <div>
                  <h3>Start without a fee</h3>
                  <p>Applying is free. You should never have to pay just to be considered.</p>
                </div>
              </div>
              <div className="candidate-point">
                <span>02</span>
                <div>
                  <h3>Learn with direction</h3>
                  <p>Training and assessment help make your skills visible and role-relevant.</p>
                </div>
              </div>
              <div className="candidate-point">
                <span>03</span>
                <div>
                  <h3>Keep expectations real</h3>
                  <p>
                    Completing training does not guarantee a job. Matching depends on readiness
                    and available roles.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="faq-section section-pad">
          <div className="content-width faq-section__grid">
            <div className="faq-section__intro reveal" data-reveal>
              <SectionHeading eyebrow="Good to know" title="A few things, clearly.">
                Straight answers about how Bridgeline works.
              </SectionHeading>
              <Link className="text-link" to="/contact">
                Still have a question? <ArrowIcon />
              </Link>
            </div>
            <div className="faq-list reveal" data-reveal>
              {questions.map((item, index) => (
                <details className="faq-item" key={item.question}>
                  <summary>
                    <span className="faq-item__number">{String(index + 1).padStart(2, '0')}</span>
                    <span>{item.question}</span>
                    <span aria-hidden="true" className="faq-item__toggle" />
                  </summary>
                  <p>{item.answer}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        <section className="closing-section">
          <div aria-hidden="true" className="closing-section__glow" />
          <div className="content-width closing-section__inner reveal" data-reveal>
            <Eyebrow light>The next step is yours</Eyebrow>
            <h2>
              Let’s build a
              <br />
              <em>stronger connection.</em>
            </h2>
            <p>Whether you’re ready to grow your skills or your team, start a conversation.</p>
            <div className="closing-section__actions">
              <Link className="button button--gold" to="/candidates">
                Apply as a candidate <ArrowIcon diagonal />
              </Link>
              <Link className="button button--outline-light" to="/employers">
                Hire through Bridgeline <ArrowIcon diagonal />
              </Link>
            </div>
          </div>
          <span aria-hidden="true" className="closing-section__index">B / 01</span>
        </section>
      </main>
      <Footer />
    </>
  )
}

function PublicPageFrame({ children }: { children: ReactNode }) {
  return (
    <>
      <a className="skip-link" href="#main-content">
        Skip to main content
      </a>
      <Header />
      <main className="public-page" id="main-content">
        {children}
      </main>
      <Footer />
    </>
  )
}

function PublicHero({
  eyebrow,
  title,
  highlight,
  description,
  action,
}: {
  eyebrow: string
  title: string
  highlight: string
  description: string
  action: { label: string; href: string }
}) {
  const actionLink =
    action.href.startsWith('#') ? (
      <a className="button button--gold" href={action.href}>
        {action.label} <ArrowIcon />
      </a>
    ) : (
      <Link className="button button--gold" to={action.href}>
        {action.label} <ArrowIcon />
      </Link>
    )

  return (
    <section className="public-hero">
      <div aria-hidden="true" className="public-hero__orb" />
      <div className="content-width public-hero__content">
        <Eyebrow light>{eyebrow}</Eyebrow>
        <h1>
          {title}
          <br />
          <em>{highlight}</em>
        </h1>
        <p>{description}</p>
        {actionLink}
      </div>
    </section>
  )
}

function FormField({
  id,
  label,
  required = false,
  error,
  hint,
  wide = false,
  children,
}: {
  id: string
  label: string
  required?: boolean
  error?: string
  hint?: string
  wide?: boolean
  children: ReactNode
}) {
  return (
    <div className={`form-field${wide ? ' form-field--wide' : ''}`}>
      <label htmlFor={id}>
        {label}
        {required && <span className="form-field__required">Required</span>}
      </label>
      {children}
      {hint && (
        <p className="form-field__hint" id={`${id}-hint`}>
          {hint}
        </p>
      )}
      {error && (
        <p className="form-field__error" id={`${id}-error`}>
          {error}
        </p>
      )}
    </div>
  )
}

function ErrorSummary({ errors }: { errors: FormErrors }) {
  const entries = Object.entries(errors)
  if (entries.length === 0) return null

  return (
    <div className="form-error-summary" role="alert">
      <p>Review these details before continuing:</p>
      <ul>
        {entries.map(([field, message]) => (
          <li key={field}>
            <a href={field === 'privacyConsent' ? '#privacyConsent' : `#${field}`}>{message}</a>
          </li>
        ))}
      </ul>
    </div>
  )
}

type SubmissionState = 'idle' | 'submitting' | 'success' | 'disabled' | 'error'

function SubmissionNotice({
  state,
  message,
}: {
  state: SubmissionState
  message: string
}) {
  if (state === 'idle') return null

  const heading = {
    submitting: 'Sending securely…',
    success: 'Submission received.',
    disabled: 'Nothing was sent.',
    error: 'Submission failed.',
    idle: '',
  }[state]

  return (
    <div
      className={`form-notice form-notice--${state}`}
      role={state === 'error' ? 'alert' : 'status'}
      tabIndex={-1}
    >
      <strong>{heading}</strong>
      <span>{message}</span>
    </div>
  )
}

function PrivacyNotice({ id, error }: { id: string; error?: string }) {
  return (
    <div className="privacy-consent">
      <div>
        <input
          aria-describedby={error ? `${id}-error` : undefined}
          aria-invalid={Boolean(error)}
          id="privacyConsent"
          name="privacyConsent"
          required
          type="checkbox"
        />
        <label htmlFor="privacyConsent">
          I have read the <Link to="/privacy">privacy information</Link> and agree to the use of
          my details for this submission.
        </label>
      </div>
      {error && (
        <p className="form-field__error" id={`${id}-error`}>
          {error}
        </p>
      )}
      {!publicSubmissionsEnabled && (
        <p className="form-privacy-note">
          Online submissions are currently disabled. Nothing you enter will be sent or stored.
        </p>
      )}
    </div>
  )
}

function usePublicForm<T extends { privacyConsent: boolean }>(
  endpoint: 'applications' | 'hiring-requests' | 'contact',
  validate: (values: T) => FormErrors,
) {
  const { accessToken } = useSession()
  const [errors, setErrors] = useState<FormErrors>({})
  const [state, setState] = useState<SubmissionState>('idle')
  const [message, setMessage] = useState('')

  async function submit(values: T) {
    setState('idle')
    setMessage('')
    const validationErrors = validate(values)
    setErrors(validationErrors)
    if (Object.keys(validationErrors).length > 0) return

    if (!publicSubmissionsEnabled) {
      setState('disabled')
      setMessage(
        'The form passed local checks, but online submissions are disabled. Your information has not been submitted or saved.',
      )
      return
    }

    setState('submitting')
    try {
      const response = await submitPublicForm(endpoint, values, accessToken)
      setState('success')
      setMessage(`Your information was received. Reference: ${response.data.id}`)
    } catch (error) {
      setState('error')
      setMessage(
        error instanceof ApiRequestError
          ? error.message
          : 'We could not reach the submission service. Your answers are still on this page; please try again.',
      )
    }
  }

  return { errors, state, message, submit }
}

function readFormValue(data: FormData, key: string) {
  const value = data.get(key)
  return typeof value === 'string' ? value : ''
}

function CandidateApplicationForm() {
  const form = usePublicForm('applications', validateCandidateApplication)

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const data = new FormData(event.currentTarget)
    const values: CandidateApplicationValues = {
      fullName: readFormValue(data, 'fullName'),
      email: readFormValue(data, 'email'),
      phone: readFormValue(data, 'phone'),
      city: readFormValue(data, 'city'),
      educationLevel: readFormValue(data, 'educationLevel'),
      currentSkills: readFormValue(data, 'currentSkills'),
      roleInterest: readFormValue(data, 'roleInterest'),
      remoteWorkReason: readFormValue(data, 'remoteWorkReason'),
      privacyConsent: data.get('privacyConsent') === 'on',
    }
    await form.submit(values)
  }

  return (
    <form className="application-form" noValidate onSubmit={handleSubmit}>
      <ErrorSummary errors={form.errors} />
      <div className="form-grid">
        <FormField error={form.errors.fullName} id="fullName" label="Full name" required>
          <input
            autoComplete="name"
            aria-describedby={form.errors.fullName ? 'fullName-error' : undefined}
            aria-invalid={Boolean(form.errors.fullName)}
            id="fullName"
            maxLength={120}
            name="fullName"
            required
          />
        </FormField>
        <FormField error={form.errors.email} id="email" label="Email address" required>
          <input
            autoComplete="email"
            aria-describedby={form.errors.email ? 'email-error' : undefined}
            aria-invalid={Boolean(form.errors.email)}
            id="email"
            maxLength={254}
            name="email"
            required
            type="email"
          />
        </FormField>
        <FormField
          error={form.errors.phone}
          hint="Include a country code if you have one."
          id="phone"
          label="Phone number"
          required
        >
          <input
            autoComplete="tel"
            aria-describedby={form.errors.phone ? 'phone-hint phone-error' : 'phone-hint'}
            aria-invalid={Boolean(form.errors.phone)}
            id="phone"
            inputMode="tel"
            maxLength={30}
            name="phone"
            required
            type="tel"
          />
        </FormField>
        <FormField error={form.errors.city} id="city" label="City" required>
          <input
            autoComplete="address-level2"
            aria-describedby={form.errors.city ? 'city-error' : undefined}
            aria-invalid={Boolean(form.errors.city)}
            id="city"
            maxLength={100}
            name="city"
            required
          />
        </FormField>
        <FormField
          error={form.errors.educationLevel}
          id="educationLevel"
          label="Education level"
          required
        >
          <select
            aria-describedby={
              form.errors.educationLevel ? 'educationLevel-error' : undefined
            }
            aria-invalid={Boolean(form.errors.educationLevel)}
            defaultValue=""
            id="educationLevel"
            name="educationLevel"
            required
          >
            <option disabled value="">
              Choose an option
            </option>
            <option value="secondary">Secondary school</option>
            <option value="certificate">Certificate or vocational training</option>
            <option value="undergraduate">Some university study</option>
            <option value="bachelors">Bachelor&apos;s degree</option>
            <option value="postgraduate">Postgraduate study</option>
            <option value="other">Other</option>
            <option value="prefer-not-to-say">Prefer not to say</option>
          </select>
        </FormField>
        <FormField
          error={form.errors.roleInterest}
          id="roleInterest"
          label="Role of interest"
          required
        >
          <select
            aria-describedby={form.errors.roleInterest ? 'roleInterest-error' : undefined}
            aria-invalid={Boolean(form.errors.roleInterest)}
            defaultValue=""
            id="roleInterest"
            name="roleInterest"
            required
          >
            <option disabled value="">
              Choose an area
            </option>
            <option value="customer-support">Customer support</option>
            <option value="virtual-assistance">Virtual assistance</option>
            <option value="operations-support">Operations support</option>
          </select>
        </FormField>
        <FormField
          error={form.errors.currentSkills}
          hint="Share relevant strengths, tools, or experience."
          id="currentSkills"
          label="Current skills"
          required
          wide
        >
          <textarea
            aria-describedby={
              form.errors.currentSkills
                ? 'currentSkills-hint currentSkills-error'
                : 'currentSkills-hint'
            }
            aria-invalid={Boolean(form.errors.currentSkills)}
            id="currentSkills"
            maxLength={1200}
            name="currentSkills"
            required
            rows={4}
          />
        </FormField>
        <FormField
          error={form.errors.remoteWorkReason}
          hint="Please write 30–1,200 characters."
          id="remoteWorkReason"
          label="Why are you interested in remote work?"
          required
          wide
        >
          <textarea
            aria-describedby={
              form.errors.remoteWorkReason
                ? 'remoteWorkReason-hint remoteWorkReason-error'
                : 'remoteWorkReason-hint'
            }
            aria-invalid={Boolean(form.errors.remoteWorkReason)}
            id="remoteWorkReason"
            maxLength={1200}
            name="remoteWorkReason"
            required
            rows={5}
          />
        </FormField>
      </div>
      <PrivacyNotice error={form.errors.privacyConsent} id="candidate-privacy-consent" />
      <SubmissionNotice message={form.message} state={form.state} />
      <button className="button button--dark form-submit" disabled={form.state === 'submitting'} type="submit">
        {form.state === 'submitting' ? 'Submitting…' : 'Submit application'} <ArrowIcon />
      </button>
      <p className="form-submit__note">Applying is free. No fee is required to apply.</p>
    </form>
  )
}

function HiringRequestForm() {
  const form = usePublicForm('hiring-requests', validateHiringRequest)

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const data = new FormData(event.currentTarget)
    const values: HiringRequestValues = {
      companyName: readFormValue(data, 'companyName'),
      contactName: readFormValue(data, 'contactName'),
      contactEmail: readFormValue(data, 'contactEmail'),
      roleNeeded: readFormValue(data, 'roleNeeded'),
      hireCount: readFormValue(data, 'hireCount'),
      salaryMin: readFormValue(data, 'salaryMin'),
      salaryMax: readFormValue(data, 'salaryMax'),
      salaryCurrency: readFormValue(data, 'salaryCurrency'),
      salaryPeriod: readFormValue(data, 'salaryPeriod'),
      timeZone: readFormValue(data, 'timeZone'),
      roleDetails: readFormValue(data, 'roleDetails'),
      privacyConsent: data.get('privacyConsent') === 'on',
    }
    await form.submit(values)
  }

  return (
    <form className="application-form" noValidate onSubmit={handleSubmit}>
      <ErrorSummary errors={form.errors} />
      <div className="form-grid">
        <FormField error={form.errors.companyName} id="companyName" label="Company name" required>
          <input
            aria-describedby={form.errors.companyName ? 'companyName-error' : undefined}
            aria-invalid={Boolean(form.errors.companyName)}
            autoComplete="organization"
            id="companyName"
            maxLength={160}
            name="companyName"
            required
          />
        </FormField>
        <FormField error={form.errors.contactName} id="contactName" label="Your name" required>
          <input
            aria-describedby={form.errors.contactName ? 'contactName-error' : undefined}
            aria-invalid={Boolean(form.errors.contactName)}
            autoComplete="name"
            id="contactName"
            maxLength={120}
            name="contactName"
            required
          />
        </FormField>
        <FormField
          error={form.errors.contactEmail}
          id="contactEmail"
          label="Work email"
          required
        >
          <input
            aria-describedby={form.errors.contactEmail ? 'contactEmail-error' : undefined}
            aria-invalid={Boolean(form.errors.contactEmail)}
            autoComplete="email"
            id="contactEmail"
            maxLength={254}
            name="contactEmail"
            required
            type="email"
          />
        </FormField>
        <FormField error={form.errors.roleNeeded} id="roleNeeded" label="Role needed" required>
          <select
            aria-describedby={form.errors.roleNeeded ? 'roleNeeded-error' : undefined}
            aria-invalid={Boolean(form.errors.roleNeeded)}
            defaultValue=""
            id="roleNeeded"
            name="roleNeeded"
            required
          >
            <option disabled value="">
              Choose a role
            </option>
            <option value="customer-support">Customer support</option>
            <option value="virtual-assistance">Virtual assistance</option>
            <option value="operations-support">Operations support</option>
          </select>
        </FormField>
        <FormField
          error={form.errors.hireCount}
          hint="Enter a whole number."
          id="hireCount"
          label="Number of hires"
          required
        >
          <input
            aria-describedby={
              form.errors.hireCount ? 'hireCount-hint hireCount-error' : 'hireCount-hint'
            }
            aria-invalid={Boolean(form.errors.hireCount)}
            id="hireCount"
            min="1"
            name="hireCount"
            required
            step="1"
            type="number"
          />
        </FormField>
        <FormField error={form.errors.timeZone} id="timeZone" label="Time zone" required>
          <input
            aria-describedby={form.errors.timeZone ? 'timeZone-error' : undefined}
            aria-invalid={Boolean(form.errors.timeZone)}
            autoComplete="off"
            id="timeZone"
            maxLength={100}
            name="timeZone"
            placeholder="e.g. UTC−5 or America/New_York"
            required
          />
        </FormField>
        <fieldset className="form-field form-field--salary">
          <legend>
            Compensation range <span className="form-field__required">Required</span>
          </legend>
          <div className="salary-fields">
            <FormField error={form.errors.salaryMin} id="salaryMin" label="Minimum" required>
              <input
                aria-describedby={form.errors.salaryMin ? 'salaryMin-error' : undefined}
                aria-invalid={Boolean(form.errors.salaryMin)}
                id="salaryMin"
                min="0"
                name="salaryMin"
                required
                step="any"
                type="number"
              />
            </FormField>
            <FormField error={form.errors.salaryMax} id="salaryMax" label="Maximum" required>
              <input
                aria-describedby={form.errors.salaryMax ? 'salaryMax-error' : undefined}
                aria-invalid={Boolean(form.errors.salaryMax)}
                id="salaryMax"
                min="0"
                name="salaryMax"
                required
                step="any"
                type="number"
              />
            </FormField>
          </div>
        </fieldset>
        <FormField
          error={form.errors.salaryCurrency}
          hint="Use a three-letter currency code, for example USD, GBP, or NGN."
          id="salaryCurrency"
          label="Currency"
          required
        >
          <input
            aria-describedby={
              form.errors.salaryCurrency
                ? 'salaryCurrency-hint salaryCurrency-error'
                : 'salaryCurrency-hint'
            }
            aria-invalid={Boolean(form.errors.salaryCurrency)}
            autoCapitalize="characters"
            id="salaryCurrency"
            maxLength={3}
            name="salaryCurrency"
            placeholder="USD"
            required
          />
        </FormField>
        <FormField
          error={form.errors.salaryPeriod}
          hint="Choose how often the stated compensation is paid."
          id="salaryPeriod"
          label="Pay period"
          required
        >
          <select
            aria-describedby={
              form.errors.salaryPeriod ? 'salaryPeriod-hint salaryPeriod-error' : 'salaryPeriod-hint'
            }
            aria-invalid={Boolean(form.errors.salaryPeriod)}
            defaultValue=""
            id="salaryPeriod"
            name="salaryPeriod"
            required
          >
            <option disabled value="">
              Choose a pay period
            </option>
            <option value="hourly">Hourly</option>
            <option value="monthly">Monthly</option>
            <option value="annual">Annual</option>
          </select>
        </FormField>
        <FormField
          error={form.errors.roleDetails}
          hint="Describe responsibilities or requirements that will help us understand the role."
          id="roleDetails"
          label="Role details (optional)"
          wide
        >
          <textarea
            aria-describedby={
              form.errors.roleDetails ? 'roleDetails-hint roleDetails-error' : 'roleDetails-hint'
            }
            aria-invalid={Boolean(form.errors.roleDetails)}
            id="roleDetails"
            maxLength={2000}
            name="roleDetails"
            rows={4}
          />
        </FormField>
      </div>
      <PrivacyNotice error={form.errors.privacyConsent} id="employer-privacy-consent" />
      <SubmissionNotice message={form.message} state={form.state} />
      <button className="button button--dark form-submit" disabled={form.state === 'submitting'} type="submit">
        {form.state === 'submitting' ? 'Submitting…' : 'Submit hiring request'} <ArrowIcon />
      </button>
      <p className="form-submit__note">
        Submitting a request does not create a hiring commitment or confirm an active vacancy.
      </p>
    </form>
  )
}

function ContactMessageForm() {
  const form = usePublicForm('contact', validateContactMessage)

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const data = new FormData(event.currentTarget)
    const values: ContactMessageValues = {
      name: readFormValue(data, 'name'),
      email: readFormValue(data, 'email'),
      subject: readFormValue(data, 'subject'),
      message: readFormValue(data, 'message'),
      privacyConsent: data.get('privacyConsent') === 'on',
    }
    await form.submit(values)
  }

  return (
    <form className="application-form contact-form" noValidate onSubmit={handleSubmit}>
      <ErrorSummary errors={form.errors} />
      <FormField error={form.errors.name} id="name" label="Name" required>
        <input
          aria-describedby={form.errors.name ? 'name-error' : undefined}
          aria-invalid={Boolean(form.errors.name)}
          autoComplete="name"
          id="name"
          maxLength={120}
          name="name"
          required
        />
      </FormField>
      <FormField error={form.errors.email} id="email" label="Email address" required>
        <input
          aria-describedby={form.errors.email ? 'email-error' : undefined}
          aria-invalid={Boolean(form.errors.email)}
          autoComplete="email"
          id="email"
          maxLength={254}
          name="email"
          required
          type="email"
        />
      </FormField>
      <FormField error={form.errors.subject} id="subject" label="Subject" required>
        <input
          aria-describedby={form.errors.subject ? 'subject-error' : undefined}
          aria-invalid={Boolean(form.errors.subject)}
          id="subject"
          maxLength={120}
          name="subject"
          required
        />
      </FormField>
      <FormField
        error={form.errors.message}
        hint="Please write 20–3,000 characters."
        id="message"
        label="Message"
        required
      >
        <textarea
          aria-describedby={
            form.errors.message ? 'message-hint message-error' : 'message-hint'
          }
          aria-invalid={Boolean(form.errors.message)}
          id="message"
          maxLength={3000}
          name="message"
          required
          rows={6}
        />
      </FormField>
      <PrivacyNotice error={form.errors.privacyConsent} id="contact-privacy-consent" />
      <SubmissionNotice message={form.message} state={form.state} />
      <button className="button button--dark form-submit" disabled={form.state === 'submitting'} type="submit">
        {form.state === 'submitting' ? 'Submitting…' : 'Send message'} <ArrowIcon />
      </button>
    </form>
  )
}

function CandidatesPage() {
  return (
    <PublicPageFrame>
      <PublicHero
        action={{ label: 'Start a free application', href: '#application' }}
        description="Build practical skills for remote work through a considered path of training and assessment. Applying is free; employment is not guaranteed."
        eyebrow="For candidates"
        highlight="Start with preparation."
        title="Your next chapter can reach further."
      />
      <section className="public-section">
        <div className="content-width public-two-column">
          <div>
            <SectionHeading eyebrow="A path with purpose" title="Make your skills count.">
              Bridgeline is being built for Nigerians who want to develop skills for remote work
              and explore opportunities with international companies.
            </SectionHeading>
          </div>
          <div className="public-detail-list">
            <article>
              <span>01</span>
              <div>
                <h3>Apply without a fee</h3>
                <p>No application fee is charged to candidates.</p>
              </div>
            </article>
            <article>
              <span>02</span>
              <div>
                <h3>Train and demonstrate</h3>
                <p>
                  Candidates who progress will take part in structured training and assessment.
                  Program details are still being finalized.
                </p>
              </div>
            </article>
            <article>
              <span>03</span>
              <div>
                <h3>Be considered for matching</h3>
                <p>
                  Assessment results and employer requirements help determine matching
                  consideration. Training does not guarantee placement.
                </p>
              </div>
            </article>
          </div>
        </div>
      </section>
      <section className="public-band">
        <div className="content-width public-band__inner">
          <Eyebrow>Initial areas of focus</Eyebrow>
          <h2>Customer support. Virtual assistance. Operations support.</h2>
          <p>These are focus areas, not a list of active vacancies.</p>
        </div>
      </section>
      <section className="public-section public-section--form" id="application">
        <div className="content-width public-form-layout">
          <div className="public-form-intro">
            <SectionHeading eyebrow="Candidate application" title="Tell us about yourself.">
              Share the information needed to understand your interests and current skills.
            </SectionHeading>
            <p className="public-form-intro__callout">
              <strong>It is free to apply.</strong> Submitting an application does not guarantee
              training or employment.
            </p>
          </div>
          <CandidateApplicationForm />
        </div>
      </section>
    </PublicPageFrame>
  )
}

function EmployersPage() {
  return (
    <PublicPageFrame>
      <PublicHero
        action={{ label: 'Share your hiring needs', href: '#hiring-request' }}
        description="Bridgeline is building a considered path for employers to meet Nigerian talent prepared for remote customer support, virtual assistance, and operations roles."
        eyebrow="For employers"
        highlight="People prepared to contribute."
        title="Build your team with"
      />
      <section className="public-section">
        <div className="content-width">
          <div className="public-section__heading">
            <SectionHeading eyebrow="A considered process" title="From role brief to introduction.">
              Share the need. We work to understand the role and consider suitable candidates
              based on relevant skills and assessment.
            </SectionHeading>
          </div>
          <div className="employer-steps">
            <article>
              <span>01 / Tell us what you need</span>
              <h3>Share the role and the context.</h3>
              <p>Include the responsibilities, time zone, and compensation range for the role.</p>
            </article>
            <article>
              <span>02 / Review and assess</span>
              <h3>Role fit matters.</h3>
              <p>
                Bridgeline’s screening approach is intended to consider role-relevant skills and
                assessment results. Specific criteria depend on the role and are being finalized.
              </p>
            </article>
            <article>
              <span>03 / Meet eligible candidates</span>
              <h3>Access is managed carefully.</h3>
              <p>
                Candidate details are shared only when Bridgeline authorizes visibility and
                applicable privacy permissions are in place.
              </p>
            </article>
          </div>
        </div>
      </section>
      <section className="public-band public-band--employer">
        <div className="content-width public-band__inner">
          <Eyebrow light>Initial focus roles</Eyebrow>
          <h2>Customer support. Virtual assistance. Operations support.</h2>
          <p>Focus roles do not indicate that a vacancy is currently available.</p>
        </div>
      </section>
      <section className="public-section public-section--form" id="hiring-request">
        <div className="content-width public-form-layout">
          <div className="public-form-intro">
            <SectionHeading eyebrow="Hiring request" title="Tell us about the role.">
              Share your requirements so Bridgeline can understand the support your team needs.
            </SectionHeading>
            <p className="public-form-intro__callout">
              Bridgeline’s model uses employer-paid placement fees. Pricing and process details
              have not been established here; a request is not a hiring commitment.
            </p>
          </div>
          <HiringRequestForm />
        </div>
      </section>
    </PublicPageFrame>
  )
}

function AboutPage() {
  return (
    <PublicPageFrame>
      <PublicHero
        action={{ label: 'Explore the candidate journey', href: '/candidates' }}
        description="Bridgeline is being built to connect the potential of Nigerian talent with the needs of remote teams—through preparation, assessment, and responsible matching."
        eyebrow="About Bridgeline"
        highlight="Train here. Work anywhere."
        title="A more considered path to"
      />
      <section className="public-section">
        <div className="content-width about-story">
          <SectionHeading eyebrow="Why Bridgeline exists" title="Potential deserves a path.">
            We believe that access to opportunity can grow when people have a chance to build
            relevant skills and demonstrate what they can do.
          </SectionHeading>
          <div className="about-story__body">
            <p>
              Bridgeline aims to help young Nigerians prepare for remote work in customer support,
              virtual assistance, and operations support, then connect qualified candidates with
              employers looking for dependable remote staff.
            </p>
            <p>
              Training and assessment are part of that path—not a promise of employment. Matching
              depends on a candidate’s assessment results, employer requirements, and available
              positions.
            </p>
          </div>
        </div>
      </section>
      <section className="public-band">
        <div className="content-width public-band__inner">
          <Eyebrow>Our approach</Eyebrow>
          <h2>Prepare with purpose. Assess with care. Connect responsibly.</h2>
          <p>
            Candidate information is not automatically public. Employers pay placement fees;
            candidates never pay to apply.
          </p>
        </div>
      </section>
      <section className="public-section about-vision">
        <div className="content-width public-two-column">
          <SectionHeading eyebrow="The long view" title="A connection that works both ways.">
            We want to make it easier for ambitious people to prepare for remote work and for
            employers to find candidates whose skills fit their needs.
          </SectionHeading>
          <div className="about-vision__note">
            <span className="about-vision__mark" aria-hidden="true">B</span>
            <p>
              Bridgeline’s programs and employer network are being developed. No company history,
              partnerships, placement results, or hiring outcomes are claimed here.
            </p>
          </div>
        </div>
      </section>
    </PublicPageFrame>
  )
}

function ContactPage() {
  return (
    <PublicPageFrame>
      <PublicHero
        action={{ label: 'Write a message', href: '#contact-form' }}
        description="Have a question about the candidate journey or hiring through Bridgeline? Use the form to prepare a message."
        eyebrow="Contact"
        highlight="Let’s start a conversation."
        title="A good connection begins with"
      />
      <section className="public-section public-section--form" id="contact-form">
        <div className="content-width public-form-layout">
          <div className="public-form-intro">
            <SectionHeading eyebrow="Get in touch" title="What would you like to know?">
              Send a note for the Bridgeline team. Online submission availability is shown before
              you send.
            </SectionHeading>
            <div className="contact-placeholder">
              <h3>Contact details</h3>
              <p>[PLACEHOLDER: confirmed company email]</p>
              <p>[PLACEHOLDER: confirmed company contact details]</p>
              <p>No office address or phone number has been supplied.</p>
            </div>
          </div>
          <ContactMessageForm />
        </div>
      </section>
    </PublicPageFrame>
  )
}

function AuthPage({ mode }: { mode: 'login' | 'candidate' | 'employer' }) {
  const { user, isLoading, sessionError, signIn, register } = useSession()
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const [errors, setErrors] = useState<FormErrors>({})
  const [requestError, setRequestError] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)
  const isRegistration = mode !== 'login'

  if (user) return <Navigate replace to="/account" />

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setErrors({})
    setRequestError('')
    const data = new FormData(event.currentTarget)
    const values: Record<string, string | boolean> = {
      fullName: readFormValue(data, 'fullName').trim(),
      email: readFormValue(data, 'email').trim(),
      password: readFormValue(data, 'password'),
      privacyConsent: data.get('privacyConsent') === 'on',
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(values.email))) {
      setErrors({ email: 'Enter a valid email address.' })
      return
    }
    if (
      String(values.password).length < 12 ||
      String(values.password).length > 72 ||
      new TextEncoder().encode(String(values.password)).length > 72
    ) {
      setErrors({ password: 'Use a password between 12 and 72 characters.' })
      return
    }
    if (isRegistration && !values.fullName) {
      setErrors({ fullName: 'Full name is required.' })
      return
    }
    if (isRegistration && !values.privacyConsent) {
      setErrors({ privacyConsent: 'Acknowledge the privacy notice to continue.' })
      return
    }

    if (mode === 'employer') {
      const companyName = readFormValue(data, 'companyName').trim()
      if (!companyName || companyName.length > 160) {
        setErrors({ companyName: 'Enter a company name of 160 characters or fewer.' })
        return
      }
      values.companyName = companyName
    }

    if (isRegistration && !publicRegistrationEnabled) {
      setRequestError('Online account registration is disabled until the privacy notice is finalized.')
      return
    }

    setIsSubmitting(true)
    try {
      if (mode === 'login') {
        await signIn(String(values.email), String(values.password))
      } else {
        await register(mode, values)
      }

      const requestedPath = searchParams.get('next')
      const destination = requestedPath?.startsWith('/') && !requestedPath.startsWith('//')
        ? requestedPath
        : '/account'
      navigate(destination, { replace: true })
    } catch (error) {
      setRequestError(
        error instanceof ApiRequestError
          ? error.message
          : 'We could not reach the account service. Your entries are still here; try again.',
      )
    } finally {
      setIsSubmitting(false)
    }
  }

  const pageTitle =
    mode === 'login'
      ? 'Welcome back.'
      : mode === 'candidate'
        ? 'Create your candidate account.'
        : 'Create your employer account.'

  return (
    <PublicPageFrame>
      <section className="public-section auth-section">
        <div className="content-width auth-layout">
          <div className="auth-intro">
            <Eyebrow>{isRegistration ? 'Create an account' : 'Account access'}</Eyebrow>
            <h1>{pageTitle}</h1>
            <p>
              {mode === 'candidate'
                ? 'Candidate accounts are for managing your own future application and profile.'
                : mode === 'employer'
                  ? 'Employer accounts are for managing your company profile and hiring requests.'
                  : 'Sign in to continue to your Bridgeline account.'}
            </p>
            {mode === 'login' ? (
              <div className="auth-intro__links">
                <Link to="/register/candidate">Create a candidate account</Link>
                <Link to="/register/employer">Create an employer account</Link>
              </div>
            ) : (
              <p className="auth-intro__switch">
                Already registered? <Link to="/login">Sign in</Link>
              </p>
            )}
          </div>
          <form className="application-form auth-form" noValidate onSubmit={handleSubmit}>
            {isLoading && <p className="auth-form__loading">Checking your existing session…</p>}
            {!isLoading && sessionError && mode === 'login' && (
              <div className="form-notice form-notice--error" role="status">
                <strong>Account service status</strong>
                <span>{sessionError}</span>
              </div>
            )}
            <ErrorSummary errors={errors} />
            {isRegistration && (
              <FormField error={errors.fullName} id="fullName" label="Full name" required>
                <input
                  autoComplete="name"
                  aria-describedby={errors.fullName ? 'fullName-error' : undefined}
                  aria-invalid={Boolean(errors.fullName)}
                  id="fullName"
                  maxLength={120}
                  name="fullName"
                  required
                />
              </FormField>
            )}
            {mode === 'employer' && (
              <FormField
                error={errors.companyName}
                id="companyName"
                label="Company name"
                required
              >
                <input
                  autoComplete="organization"
                  aria-describedby={errors.companyName ? 'companyName-error' : undefined}
                  aria-invalid={Boolean(errors.companyName)}
                  id="companyName"
                  maxLength={160}
                  name="companyName"
                  required
                />
              </FormField>
            )}
            <FormField error={errors.email} id="email" label="Email address" required>
              <input
                autoComplete="email"
                aria-describedby={errors.email ? 'email-error' : undefined}
                aria-invalid={Boolean(errors.email)}
                id="email"
                maxLength={254}
                name="email"
                required
                type="email"
              />
            </FormField>
            <FormField
              error={errors.password}
              hint=              {isRegistration ? 'Use 12–72 characters.' : undefined}
              id="password"
              label="Password"
              required
            >
              <input
                autoComplete={isRegistration ? 'new-password' : 'current-password'}
                aria-describedby={
                  errors.password
                    ? isRegistration
                      ? 'password-hint password-error'
                      : 'password-error'
                    : isRegistration
                      ? 'password-hint'
                      : undefined
                }
                aria-invalid={Boolean(errors.password)}
                id="password"
                maxLength={72}
                minLength={isRegistration ? 12 : undefined}
                name="password"
                required
                type="password"
              />
            </FormField>
            {isRegistration && (
              <PrivacyNotice error={errors.privacyConsent} id="account-privacy-consent" />
            )}
            {isRegistration && !publicRegistrationEnabled && (
              <p className="form-privacy-note">
                Online account registration is currently disabled. No account data will be sent or
                saved.
              </p>
            )}
            {requestError && (
              <div className="form-notice form-notice--error" role="alert">
                <strong>We couldn&apos;t complete that request.</strong>
                <span>{requestError}</span>
              </div>
            )}
            <button
              className="button button--dark form-submit"
              disabled={isLoading || isSubmitting}
              type="submit"
            >
              {isSubmitting
                ? 'Please wait…'
                : isRegistration
                  ? 'Create account'
                  : 'Sign in'}
              <ArrowIcon />
            </button>
            {mode === 'login' && (
              <p className="form-submit__note">
                Password recovery is not available yet. Contact details are shown on the contact page.
              </p>
            )}
          </form>
        </div>
      </section>
    </PublicPageFrame>
  )
}

function ProtectedAccountPage() {
  const { user, isLoading, signOut } = useSession()
  const location = useLocation()
  const navigate = useNavigate()

  if (isLoading) {
    return (
      <main className="account-loading" aria-live="polite">
        Checking your session…
      </main>
    )
  }
  if (!user) {
    const next = encodeURIComponent(`${location.pathname}${location.search}`)
    return <Navigate replace to={`/login?next=${next}`} />
  }

  async function handleSignOut() {
    try {
      await signOut()
      navigate('/', { replace: true })
    } catch {
      return
    }
  }

  return (
    <PublicPageFrame>
      <Suspense
        fallback={
          <section className="dashboard-page" aria-live="polite">
            <div className="dashboard-container">Loading your workspace…</div>
          </section>
        }
      >
        <DashboardPage onSignOut={() => void handleSignOut()} />
      </Suspense>
    </PublicPageFrame>
  )
}

function PrivacyPage() {
  return (
    <PublicPageFrame>
      <section className="public-section privacy-page">
        <div className="content-width">
          <Eyebrow>Privacy information · Draft</Eyebrow>
          <h1>Privacy comes before submission.</h1>
          <p className="privacy-page__lead">
            This is a preliminary project notice, not a final privacy policy or a claim of legal
            compliance. Online account registration and public form submissions are disabled by
            default.
          </p>
          <div className="privacy-page__body">
            <section>
              <h2>Information the forms may ask for</h2>
              <p>
                Candidate forms ask for contact details, city, education level, skills, role
                interest, and a short explanation of interest in remote work. Employer forms ask
                for company and contact details, hiring needs, compensation range, currency, pay
                period, and time zone. Contact forms ask for name, email, subject, and message.
              </p>
            </section>
            <section>
              <h2>Why it would be used</h2>
              <p>
                If submissions are enabled after review, information would be used to review a
                candidate application, respond to a hiring request or contact message, and operate
                the related account. Candidate details are not automatically made public or shared
                with employers.
              </p>
            </section>
            <section>
              <h2>Access, storage, and retention</h2>
              <p>
                The planned service stores submissions in PostgreSQL and restricts application
                access by role. A final retention schedule, deletion process, contact channel, and
                all operational safeguards must be established before collecting real submissions.
              </p>
            </section>
            <section>
              <h2>Before this notice is put into effect</h2>
              <p>
                Bridgeline must supply confirmed contact details, determine the applicable
                jurisdiction-specific requirements, and have this notice reviewed and finalized.
                Do not submit sensitive personal information. No legal-compliance certification
                is made by this draft.
              </p>
            </section>
          </div>
        </div>
      </section>
    </PublicPageFrame>
  )
}

function Footer() {
  return (
    <footer className="site-footer">
      <div className="content-width">
        <div className="site-footer__main">
          <div className="site-footer__brand">
            <Wordmark light />
            <p>Train here. Work anywhere.</p>
          </div>
          <div className="site-footer__column">
            <h2>Explore</h2>
            <Link to="/">Home</Link>
            <Link to="/about">About Bridgeline</Link>
            <Link to="/contact">Contact</Link>
          </div>
          <div className="site-footer__column">
            <h2>Get started</h2>
            <Link to="/candidates">For candidates</Link>
            <Link to="/employers">For employers</Link>
            <Link to="/login">Sign in</Link>
          </div>
          <div className="site-footer__column">
            <h2>Contact</h2>
            <span>[PLACEHOLDER: confirmed company email]</span>
            <span>[PLACEHOLDER: confirmed company contact details]</span>
          </div>
        </div>
        <div className="site-footer__bottom">
          <p>© {currentYear} Bridgeline. All rights reserved.</p>
          <p>Train here. Work anywhere.</p>
          <div>
            <Link to="/privacy">Privacy</Link>
            <Link to="/terms">Terms</Link>
          </div>
        </div>
      </div>
    </footer>
  )
}

function UnavailablePage() {
  const location = useLocation()
  const labels: Record<string, string> = {
    '/candidates': 'For candidates',
    '/employers': 'For employers',
    '/about': 'About Bridgeline',
    '/contact': 'Contact',
    '/terms': 'Terms',
  }
  const pageName = labels[location.pathname] ?? 'This page'

  return (
    <main className="unavailable-page">
      <Wordmark />
      <div>
        <Eyebrow>Coming in a later phase</Eyebrow>
        <h1>{pageName} is not available yet.</h1>
        <p>
          This part of Bridgeline is planned, but it is not available yet. No application or
          hiring request has been submitted.
        </p>
        <Link className="button button--gold" to="/">
          Return to the homepage <ArrowIcon />
        </Link>
      </div>
    </main>
  )
}

const routeMetadata: Record<
  string,
  { title: string; description: string; index: boolean }
> = {
  '/': {
    title: 'Bridgeline — Train here. Work anywhere.',
    description:
      'Bridgeline prepares Nigerian talent for remote work and connects qualified candidates with international employers.',
    index: true,
  },
  '/candidates': {
    title: 'For Candidates | Bridgeline',
    description:
      'Explore Bridgeline training and remote-work opportunities for Nigerian candidates. Training does not guarantee placement.',
    index: true,
  },
  '/employers': {
    title: 'For Employers | Bridgeline',
    description:
      'Connect with prepared Nigerian remote talent in customer support, virtual assistance, and operations support.',
    index: true,
  },
  '/about': {
    title: 'About Bridgeline',
    description:
      'Learn about Bridgeline’s goal of creating a considered path between Nigerian talent and global remote work.',
    index: true,
  },
  '/contact': {
    title: 'Contact Bridgeline',
    description: 'Contact Bridgeline with questions about candidate training or hiring.',
    index: true,
  },
  '/privacy': {
    title: 'Draft Privacy Notice | Bridgeline',
    description:
      'The Bridgeline privacy notice is a draft and must be reviewed before online submissions are enabled.',
    index: false,
  },
  '/login': {
    title: 'Sign In | Bridgeline',
    description: 'Sign in to your Bridgeline account.',
    index: false,
  },
  '/register/candidate': {
    title: 'Candidate Registration | Bridgeline',
    description: 'Create a candidate account with Bridgeline.',
    index: false,
  },
  '/register/employer': {
    title: 'Employer Registration | Bridgeline',
    description: 'Create an employer account with Bridgeline.',
    index: false,
  },
  '/account': {
    title: 'Account Workspace | Bridgeline',
    description: 'Manage your private Bridgeline account workspace.',
    index: false,
  },
}

function RouteMetadata() {
  const location = useLocation()

  useEffect(() => {
    const metadata = routeMetadata[location.pathname] ?? {
      title: 'Page Not Found | Bridgeline',
      description: 'The requested Bridgeline page could not be found.',
      index: false,
    }
    document.title = metadata.title
    document.getElementById('page-description')?.setAttribute('content', metadata.description)
    document.getElementById('page-robots')?.setAttribute(
      'content',
      metadata.index ? 'index,follow' : 'noindex,nofollow',
    )
    document.getElementById('page-og-title')?.setAttribute('content', metadata.title)
    document.getElementById('page-og-description')?.setAttribute('content', metadata.description)

    const canonical = document.getElementById('canonical-url') as HTMLLinkElement | null
    const siteUrl = import.meta.env.VITE_SITE_URL
    if (!canonical || !siteUrl || !metadata.index) {
      canonical?.removeAttribute('href')
      return
    }
    try {
      const baseUrl = new URL(siteUrl)
      canonical.href = new URL(location.pathname, baseUrl).toString()
    } catch {
      canonical.removeAttribute('href')
    }
  }, [location.pathname])

  return null
}

function App() {
  return (
    <BrowserRouter>
      <SessionProvider>
        <RouteMetadata />
        <Suspense
          fallback={
            <main className="account-loading" aria-live="polite">
              Loading page…
            </main>
          }
        >
          <Routes>
            <Route element={<HomePage />} path="/" />
            <Route element={<CandidatesPage />} path="/candidates" />
            <Route element={<EmployersPage />} path="/employers" />
            <Route element={<AboutPage />} path="/about" />
            <Route element={<ContactPage />} path="/contact" />
            <Route element={<PrivacyPage />} path="/privacy" />
            <Route element={<AuthPage mode="login" />} path="/login" />
            <Route element={<AuthPage mode="candidate" />} path="/register/candidate" />
            <Route element={<AuthPage mode="employer" />} path="/register/employer" />
            <Route element={<ProtectedAccountPage />} path="/account" />
            <Route element={<UnavailablePage />} path="*" />
          </Routes>
        </Suspense>
      </SessionProvider>
    </BrowserRouter>
  )
}

export default App
