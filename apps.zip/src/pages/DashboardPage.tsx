import { useCallback, useEffect, useState, type FormEvent, type ReactNode } from 'react'
import {
  ApiRequestError,
  authorizeAdminMatch,
  createAdminPlacement,
  getAdminDashboard,
  getCandidateDashboard,
  getEmployerDashboard,
  getEmployerMatches,
  updateAdminApplicationStatus,
  updateAdminAssessment,
  updateAdminHiringStatus,
  updateAdminTraining,
  updateCandidateProfile,
  updateCandidateVisibility,
  updateEmployerProfile,
  type AdminActivity,
  type AdminApplication,
  type AdminHiringRequest,
  type AdminPlacement,
  type CandidateDashboard,
  type CandidateProfileUpdate,
  type EmployerDashboard,
  type EmployerMatch,
} from '../lib/api'
import { useSession } from '../lib/useSession'

function displayStatus(value: string) {
  return value
    .toLowerCase()
    .replaceAll('_', ' ')
    .replace(/\b\w/g, (letter) => letter.toUpperCase())
}

function roleName(value: string) {
  return displayStatus(value.replace(/-/g, '_'))
}

function dateLabel(value: string) {
  return new Intl.DateTimeFormat(undefined, { dateStyle: 'medium' }).format(new Date(value))
}

function Panel({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="dashboard-card">
      <div className="dashboard-card__heading">
        <h2>{title}</h2>
      </div>
      {children}
    </section>
  )
}

export function DashboardPage({ onSignOut }: { onSignOut: () => void }) {
  const { accessToken, user, sessionError } = useSession()
  const [candidate, setCandidate] = useState<CandidateDashboard | null>(null)
  const [employer, setEmployer] = useState<EmployerDashboard | null>(null)
  const [matches, setMatches] = useState<EmployerMatch[]>([])
  const [admin, setAdmin] = useState<{
    applications: AdminApplication[]
    hiringRequests: AdminHiringRequest[]
    placements: AdminPlacement[]
    activity: AdminActivity[]
  } | null>(null)
  const [profile, setProfile] = useState<CandidateProfileUpdate & { companyName?: string }>({})
  const [selectedRequests, setSelectedRequests] = useState<Record<string, string>>({})
  const [trainingPercentages, setTrainingPercentages] = useState<Record<string, number>>({})
  const [reviewNotes, setReviewNotes] = useState<Record<string, string>>({})
  const [loading, setLoading] = useState(true)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(sessionError)
  const [notice, setNotice] = useState<string | null>(null)

  const loadDashboard = useCallback(async () => {
    if (!accessToken || !user) return
    if (user.role === 'CANDIDATE') {
      const data = await getCandidateDashboard(accessToken)
      setError(null)
      setCandidate(data)
      setProfile({
        fullName: data.fullName,
        phone: data.candidateProfile?.phone ?? '',
        city: data.candidateProfile?.city ?? '',
        educationLevel: data.candidateProfile?.educationLevel ?? '',
        currentSkills: data.candidateProfile?.currentSkills ?? '',
        roleInterest: data.candidateProfile?.roleInterest ?? undefined,
      })
    } else if (user.role === 'EMPLOYER') {
      const [data, authorizedMatches] = await Promise.all([
        getEmployerDashboard(accessToken),
        getEmployerMatches(accessToken),
      ])
      setError(null)
      setEmployer(data)
      setMatches(authorizedMatches)
      setProfile({ fullName: data.fullName, companyName: data.employerProfile?.companyName ?? '' })
    } else {
      const data = await getAdminDashboard(accessToken)
      setError(null)
      setAdmin(data)
    }
  }, [accessToken, user])

  useEffect(() => {
    let active = true
    void Promise.resolve()
      .then(loadDashboard)
      .catch((cause: unknown) => {
        if (active) {
          setError(cause instanceof Error ? cause.message : 'The dashboard could not be loaded.')
        }
      })
      .finally(() => {
        if (active) setLoading(false)
      })
    return () => {
      active = false
    }
  }, [loadDashboard])

  async function perform(action: () => Promise<unknown>, message: string) {
    setBusy(true)
    setError(null)
    setNotice(null)
    try {
      await action()
      await loadDashboard()
      setNotice(message)
    } catch (cause) {
      setError(
        cause instanceof ApiRequestError || cause instanceof Error
          ? cause.message
          : 'The action could not be completed.',
      )
    } finally {
      setBusy(false)
    }
  }

  function submitProfile(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!accessToken || user?.role !== 'CANDIDATE') return
    const values: CandidateProfileUpdate = {
      fullName: profile.fullName?.trim(),
      phone: profile.phone?.trim() || null,
      city: profile.city?.trim() || null,
      educationLevel: profile.educationLevel?.trim() || null,
      currentSkills: profile.currentSkills?.trim() || null,
      roleInterest: profile.roleInterest ?? null,
    }
    void perform(
      () => updateCandidateProfile(accessToken, values),
      'Your profile has been updated.',
    )
  }

  function submitEmployerProfile(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!accessToken || user?.role !== 'EMPLOYER') return
    void perform(
      () =>
        updateEmployerProfile(accessToken, {
          fullName: profile.fullName?.trim(),
          companyName: profile.companyName?.trim(),
        }),
      'Your company profile has been updated.',
    )
  }

  async function updateVisibility(consent: boolean) {
    if (!accessToken) return
    const confirmText = consent
      ? 'Allow employers to view your candidate profile after an administrator approves a match?'
      : 'Revoke consent for employers to view your profile? Existing authorized matches will no longer display it.'
    if (!window.confirm(confirmText)) return
    await perform(
      () => updateCandidateVisibility(accessToken, consent),
      consent ? 'Profile-sharing consent has been recorded.' : 'Profile-sharing consent has been revoked.',
    )
  }

  async function setApplicationStatus(id: string, status: string) {
    if (!accessToken) return
    await perform(
      () =>
        updateAdminApplicationStatus(accessToken, id, {
          status,
          ...(reviewNotes[id] === undefined ? {} : { internalReviewNote: reviewNotes[id] }),
        }),
      `Application moved to ${displayStatus(status)}.`,
    )
  }

  async function setHiringStatus(id: string, status: string) {
    if (!accessToken) return
    await perform(
      () => updateAdminHiringStatus(accessToken, id, status),
      `Hiring request moved to ${displayStatus(status)}.`,
    )
  }

  async function saveTraining(id: string, current: number) {
    if (!accessToken) return
    await perform(
      () =>
        updateAdminTraining(accessToken, id, {
          percentage: trainingPercentages[id] ?? current,
        }),
      'Training progress has been saved.',
    )
  }

  async function recordAssessment(id: string, status: 'PASSED' | 'FAILED') {
    if (!accessToken) return
    await perform(
      () => updateAdminAssessment(accessToken, id, { status }),
      `Assessment recorded as ${status.toLowerCase()}.`,
    )
  }

  async function authorizeMatch(applicationId: string) {
    if (!accessToken) return
    const requestId = selectedRequests[applicationId]
    if (!requestId) {
      setError('Choose an active hiring request before authorizing a match.')
      return
    }
    await perform(
      () => authorizeAdminMatch(accessToken, applicationId, requestId),
      'The match has been authorized.',
    )
  }

  async function placeCandidate(applicationId: string, hiringRequestId: string) {
    if (!accessToken) return
    if (!window.confirm('Confirm this candidate placement? This will update the application and hiring request.')) {
      return
    }
    await perform(
      () => createAdminPlacement(accessToken, applicationId, hiringRequestId),
      'The placement has been recorded.',
    )
  }

  if (!user) return null
  const roleLabel = { CANDIDATE: 'Candidate', EMPLOYER: 'Employer', ADMIN: 'Administrator' }[
    user.role
  ]

  return (
    <section className="dashboard-page">
      <div className="dashboard-container">
        <header className="dashboard-header">
          <div>
            <p className="dashboard-eyebrow">{roleLabel} workspace</p>
            <h1>Welcome, {user.fullName}.</h1>
            <p>{user.email}</p>
          </div>
          <button className="button button--dark button--small" onClick={onSignOut} type="button">
            Sign out
          </button>
        </header>

        {error && <p className="dashboard-alert dashboard-alert--error" role="alert">{error}</p>}
        {notice && <p className="dashboard-alert dashboard-alert--success" role="status">{notice}</p>}
        {loading ? (
          <p className="dashboard-loading" aria-live="polite">Loading your workspace…</p>
        ) : (
          <>
            {user.role === 'CANDIDATE' && candidate && (
              <div className="dashboard-grid">
                <Panel title="Your profile">
                  <form className="dashboard-form" onSubmit={submitProfile}>
                    <label>
                      Full name
                      <input
                        autoComplete="name"
                        maxLength={120}
                        onChange={(event) => setProfile({ ...profile, fullName: event.target.value })}
                        required
                        value={profile.fullName ?? ''}
                      />
                    </label>
                    <label>
                      Phone
                      <input
                        autoComplete="tel"
                        maxLength={30}
                        onChange={(event) => setProfile({ ...profile, phone: event.target.value })}
                        value={profile.phone ?? ''}
                      />
                    </label>
                    <label>
                      City
                      <input
                        maxLength={100}
                        onChange={(event) => setProfile({ ...profile, city: event.target.value })}
                        value={profile.city ?? ''}
                      />
                    </label>
                    <label>
                      Education
                      <input
                        maxLength={80}
                        onChange={(event) =>
                          setProfile({ ...profile, educationLevel: event.target.value })
                        }
                        value={profile.educationLevel ?? ''}
                      />
                    </label>
                    <label>
                      Skills and experience
                      <textarea
                        maxLength={1200}
                        onChange={(event) =>
                          setProfile({ ...profile, currentSkills: event.target.value })
                        }
                        rows={4}
                        value={profile.currentSkills ?? ''}
                      />
                    </label>
                    <label>
                      Role interest
                      <select
                        onChange={(event) =>
                          setProfile({
                            ...profile,
                            roleInterest: event.target.value
                              ? (event.target.value as NonNullable<
                                  CandidateProfileUpdate['roleInterest']
                                >)
                              : undefined,
                          })
                        }
                        value={profile.roleInterest ?? ''}
                      >
                        <option value="">Select a role</option>
                        <option value="CUSTOMER_SUPPORT">Customer support</option>
                        <option value="VIRTUAL_ASSISTANCE">Virtual assistance</option>
                        <option value="OPERATIONS_SUPPORT">Operations support</option>
                      </select>
                    </label>
                    <button className="button button--dark" disabled={busy} type="submit">
                      Save profile
                    </button>
                  </form>
                  <div className="dashboard-consent">
                    <div>
                      <strong>Employer profile visibility</strong>
                      <p>
                        Employers only see your profile when you consent and an administrator
                        authorizes a match. You can revoke consent at any time.
                      </p>
                      <span className="dashboard-status">
                        {candidate.candidateProfile?.employerVisibilityConsentAt
                          ? 'Consent active'
                          : 'Not shared'}
                      </span>
                    </div>
                    <button
                      className="button button--small button--outline"
                      disabled={busy}
                      onClick={() =>
                        void updateVisibility(!candidate.candidateProfile?.employerVisibilityConsentAt)
                      }
                      type="button"
                    >
                      {candidate.candidateProfile?.employerVisibilityConsentAt
                        ? 'Revoke consent'
                        : 'Give consent'}
                    </button>
                  </div>
                </Panel>
                <Panel title="Application progress">
                  {candidate.applications.length === 0 ? (
                    <p className="dashboard-empty">
                      No applications are linked to this account yet. Your application progress
                      will appear here when an application is received.
                    </p>
                  ) : (
                    <div className="dashboard-list">
                      {candidate.applications.map((application) => (
                        <article className="dashboard-list-item" key={application.id}>
                          <div className="dashboard-list-item__top">
                            <strong>{roleName(application.roleInterest)}</strong>
                            <span className="dashboard-status">{displayStatus(application.status)}</span>
                          </div>
                          <p>Received {dateLabel(application.createdAt)}</p>
                          {application.trainingProgress && (
                            <div className="dashboard-progress">
                              <div>
                                <span>Training</span>
                                <strong>{application.trainingProgress.percentage}%</strong>
                              </div>
                              <progress
                                aria-label={`Training progress: ${application.trainingProgress.percentage}%`}
                                max={100}
                                value={application.trainingProgress.percentage}
                              />
                            </div>
                          )}
                          {application.assessment && (
                            <p>Assessment: {displayStatus(application.assessment.status)}</p>
                          )}
                          {application.employerMatches.map((match) => (
                            <p className="dashboard-update" key={match.authorizedAt}>
                              An administrator authorized a match with {match.hiringRequest.companyName}.
                            </p>
                          ))}
                          {application.placement && (
                            <p className="dashboard-update">
                              Placed with {application.placement.hiringRequest.companyName} on{' '}
                              {dateLabel(application.placement.placedAt)}.
                            </p>
                          )}
                        </article>
                      ))}
                    </div>
                  )}
                </Panel>
              </div>
            )}

            {user.role === 'EMPLOYER' && employer && (
              <div className="dashboard-grid">
                <Panel title="Company profile">
                  <form className="dashboard-form" onSubmit={submitEmployerProfile}>
                    <label>
                      Contact name
                      <input
                        autoComplete="name"
                        maxLength={120}
                        onChange={(event) => setProfile({ ...profile, fullName: event.target.value })}
                        required
                        value={profile.fullName ?? ''}
                      />
                    </label>
                    <label>
                      Company name
                      <input
                        maxLength={160}
                        onChange={(event) =>
                          setProfile({ ...profile, companyName: event.target.value })
                        }
                        required
                        value={profile.companyName ?? ''}
                      />
                    </label>
                    <button className="button button--dark" disabled={busy} type="submit">
                      Save company profile
                    </button>
                  </form>
                </Panel>
                <Panel title="Hiring requests">
                  {employer.hiringRequests.length === 0 ? (
                    <p className="dashboard-empty">
                      No hiring requests are linked to this account yet. Request status and
                      placement updates will appear here.
                    </p>
                  ) : (
                    <div className="dashboard-list">
                      {employer.hiringRequests.map((item) => (
                        <article className="dashboard-list-item" key={item.id}>
                          <div className="dashboard-list-item__top">
                            <strong>{roleName(item.roleNeeded)}</strong>
                            <span className="dashboard-status">{displayStatus(item.status)}</span>
                          </div>
                          <p>
                            {item.hireCount} position{item.hireCount === 1 ? '' : 's'} ·{' '}
                            {item.salaryCurrency} {item.salaryMin}–{item.salaryMax} /{' '}
                            {displayStatus(item.salaryPeriod)}
                          </p>
                          <p>Submitted {dateLabel(item.createdAt)}</p>
                          <p>
                            {item._count.employerMatches} authorized match
                            {item._count.employerMatches === 1 ? '' : 'es'} ·{' '}
                            {item._count.placements} placement{item._count.placements === 1 ? '' : 's'}
                          </p>
                        </article>
                      ))}
                    </div>
                  )}
                </Panel>
                <Panel title="Administrator-authorized candidates">
                  {matches.length === 0 ? (
                    <p className="dashboard-empty">
                      No candidates have been matched to your requests. Candidate details remain
                      private until the candidate consents and an administrator authorizes a match.
                    </p>
                  ) : (
                    <div className="dashboard-list">
                      {matches.map((match) => (
                        <article className="dashboard-list-item" key={match.id}>
                          <div className="dashboard-list-item__top">
                            <strong>
                              {match.candidateApplication.user?.fullName ??
                                match.candidateApplication.fullName}
                            </strong>
                            <span className="dashboard-status">
                              {roleName(match.candidateApplication.roleInterest)}
                            </span>
                          </div>
                          <p>
                            Matched to {match.hiringRequest.companyName} ·{' '}
                            {dateLabel(match.authorizedAt)}
                          </p>
                          <p>
                            {match.candidateApplication.user?.email ??
                              match.candidateApplication.email}{' '}
                            ·{' '}
                            {match.candidateApplication.user?.candidateProfile?.phone ??
                              match.candidateApplication.phone}
                          </p>
                          <p>
                            {match.candidateApplication.user?.candidateProfile?.city ??
                              match.candidateApplication.city}{' '}
                            ·{' '}
                            {match.candidateApplication.user?.candidateProfile?.educationLevel ??
                              match.candidateApplication.educationLevel}
                          </p>
                          <p>
                            {match.candidateApplication.user?.candidateProfile?.currentSkills ??
                              match.candidateApplication.currentSkills}
                          </p>
                        </article>
                      ))}
                    </div>
                  )}
                </Panel>
              </div>
            )}

            {user.role === 'ADMIN' && admin && (
              <div className="dashboard-grid dashboard-grid--admin">
                <Panel title={`Applications · ${admin.applications.length}`}>
                  {admin.applications.length === 0 ? (
                    <p className="dashboard-empty">There are no applications to review.</p>
                  ) : (
                    <div className="dashboard-list">
                      {admin.applications.map((application) => (
                        <AdminApplicationCard
                          application={application}
                          busy={busy}
                          hiringRequests={admin.hiringRequests}
                          key={application.id}
                          onAssessment={recordAssessment}
                          onMatch={authorizeMatch}
                          onPlace={placeCandidate}
                          onSelectRequest={(id, value) =>
                            setSelectedRequests({ ...selectedRequests, [id]: value })
                          }
                          onStatus={setApplicationStatus}
                          onTraining={saveTraining}
                          selectedRequest={selectedRequests[application.id] ?? ''}
                          trainingPercentage={
                            trainingPercentages[application.id] ??
                            application.trainingProgress?.percentage ??
                            0
                          }
                          onTrainingPercentage={(id, value) =>
                            setTrainingPercentages({ ...trainingPercentages, [id]: value })
                          }
                          reviewNote={reviewNotes[application.id] ?? application.internalReviewNote ?? ''}
                          onReviewNote={(id, value) =>
                            setReviewNotes({ ...reviewNotes, [id]: value })
                          }
                        />
                      ))}
                    </div>
                  )}
                </Panel>
                <Panel title={`Hiring requests · ${admin.hiringRequests.length}`}>
                  {admin.hiringRequests.length === 0 ? (
                    <p className="dashboard-empty">There are no hiring requests to review.</p>
                  ) : (
                    <div className="dashboard-list">
                      {admin.hiringRequests.map((item) => (
                        <article className="dashboard-list-item" key={item.id}>
                          <div className="dashboard-list-item__top">
                            <strong>{item.companyName} · {roleName(item.roleNeeded)}</strong>
                            <span className="dashboard-status">{displayStatus(item.status)}</span>
                          </div>
                          <p>{item.contactName} · {item.contactEmail}</p>
                          <p>
                            {item.salaryCurrency} {item.salaryMin}–{item.salaryMax} /{' '}
                            {displayStatus(item.salaryPeriod)} · {item.timeZone}
                          </p>
                          {item.roleDetails && <p>{item.roleDetails}</p>}
                          <p>
                            {item.placedCount}/{item.hireCount} placements ·{' '}
                            {item._count.employerMatches} authorized matches
                          </p>
                          <div className="dashboard-actions">
                            {item.status === 'SUBMITTED' && (
                              <button
                                className="button button--small button--outline"
                                disabled={busy}
                                onClick={() => void setHiringStatus(item.id, 'UNDER_REVIEW')}
                                type="button"
                              >
                                Start review
                              </button>
                            )}
                            {item.status === 'UNDER_REVIEW' && (
                              <>
                                <button
                                  className="button button--small button--outline"
                                  disabled={busy}
                                  onClick={() => void setHiringStatus(item.id, 'IN_PROGRESS')}
                                  type="button"
                                >
                                  Open hiring
                                </button>
                                <button
                                  className="button button--small button--outline"
                                  disabled={busy}
                                  onClick={() => void setHiringStatus(item.id, 'CLOSED')}
                                  type="button"
                                >
                                  Close
                                </button>
                              </>
                            )}
                            {item.status === 'IN_PROGRESS' && item.placedCount < item.hireCount && (
                              <button
                                className="button button--small button--outline"
                                disabled={busy}
                                onClick={() => void setHiringStatus(item.id, 'CLOSED')}
                                type="button"
                              >
                                Close
                              </button>
                            )}
                          </div>
                        </article>
                      ))}
                    </div>
                  )}
                </Panel>
                <Panel title={`Placements · ${admin.placements.length}`}>
                  {admin.placements.length === 0 ? (
                    <p className="dashboard-empty">No placements have been recorded.</p>
                  ) : (
                    <div className="dashboard-list">
                      {admin.placements.map((placement) => (
                        <article className="dashboard-list-item" key={placement.id}>
                          <strong>{placement.candidateApplication.fullName}</strong>
                          <p>
                            {roleName(placement.candidateApplication.roleInterest)} at{' '}
                            {placement.hiringRequest.companyName}
                          </p>
                          <p>{dateLabel(placement.placedAt)}</p>
                        </article>
                      ))}
                    </div>
                  )}
                </Panel>
                <Panel title="Recent administrative activity">
                  {admin.activity.length === 0 ? (
                    <p className="dashboard-empty">Administrative actions will be recorded here.</p>
                  ) : (
                    <div className="dashboard-list">
                      {admin.activity.slice(0, 12).map((event) => (
                        <article className="dashboard-list-item" key={event.id}>
                          <strong>{displayStatus(event.action)}</strong>
                          <p>
                            {event.actor.fullName} · {displayStatus(event.entityType)} ·{' '}
                            {dateLabel(event.createdAt)}
                          </p>
                        </article>
                      ))}
                    </div>
                  )}
                </Panel>
              </div>
            )}
          </>
        )}
      </div>
    </section>
  )
}

function AdminApplicationCard({
  application,
  hiringRequests,
  selectedRequest,
  trainingPercentage,
  reviewNote,
  busy,
  onSelectRequest,
  onTrainingPercentage,
  onReviewNote,
  onStatus,
  onTraining,
  onAssessment,
  onMatch,
  onPlace,
}: {
  application: AdminApplication
  hiringRequests: AdminHiringRequest[]
  selectedRequest: string
  trainingPercentage: number
  reviewNote: string
  busy: boolean
  onSelectRequest: (id: string, requestId: string) => void
  onTrainingPercentage: (id: string, percentage: number) => void
  onReviewNote: (id: string, note: string) => void
  onStatus: (id: string, status: string) => void
  onTraining: (id: string, current: number) => void
  onAssessment: (id: string, status: 'PASSED' | 'FAILED') => void
  onMatch: (id: string) => void
  onPlace: (applicationId: string, requestId: string) => void
}) {
  const activeMatches = application.employerMatches ?? []
  const availableRequests = hiringRequests.filter(
    (request) =>
      request.status === 'IN_PROGRESS' &&
      request.roleNeeded === application.roleInterest &&
      !activeMatches.some((match) => match.hiringRequestId === request.id),
  )

  return (
    <article className="dashboard-list-item">
      <div className="dashboard-list-item__top">
        <strong>{application.fullName} · {roleName(application.roleInterest)}</strong>
        <span className="dashboard-status">{displayStatus(application.status)}</span>
      </div>
      <p>
        {application.email} · {application.phone} · {application.city} ·{' '}
        {application.educationLevel} · Received {dateLabel(application.createdAt)}
      </p>
      <p>Skills and experience: {application.currentSkills}</p>
      <p>Motivation: {application.remoteWorkReason}</p>
      {(application.status === 'SUBMITTED' || application.status === 'UNDER_REVIEW') && (
        <label className="dashboard-review-note">
          Internal review note
          <textarea
            maxLength={2000}
            onChange={(event) => onReviewNote(application.id, event.target.value)}
            rows={2}
            value={reviewNote}
          />
        </label>
      )}
      {application.trainingProgress && (
        <p>Training: {application.trainingProgress.percentage}%</p>
      )}
      {application.assessment && (
        <p>Assessment: {displayStatus(application.assessment.status)}</p>
      )}
      <div className="dashboard-actions">
        {application.status === 'SUBMITTED' && (
          <button
            className="button button--small button--outline"
            disabled={busy}
            onClick={() => void onStatus(application.id, 'UNDER_REVIEW')}
            type="button"
          >
            Start review
          </button>
        )}
        {application.status === 'UNDER_REVIEW' && (
          <>
            <button
              className="button button--small button--outline"
              disabled={busy}
              onClick={() => void onStatus(application.id, 'APPROVED')}
              type="button"
            >
              Approve
            </button>
            <button
              className="button button--small button--outline"
              disabled={busy}
              onClick={() => void onStatus(application.id, 'REJECTED')}
              type="button"
            >
              Reject
            </button>
          </>
        )}
        {application.status === 'APPROVED' && (
          <button
            className="button button--small button--outline"
            disabled={busy}
            onClick={() => void onStatus(application.id, 'IN_TRAINING')}
            type="button"
          >
            Start training
          </button>
        )}
        {application.status === 'IN_TRAINING' && (
          <form
            className="dashboard-inline-form"
            onSubmit={(event) => {
              event.preventDefault()
              void onTraining(application.id, trainingPercentage)
            }}
          >
            <label>
              Training completion %
              <input
                max={100}
                min={0}
                onChange={(event) =>
                  onTrainingPercentage(application.id, Number(event.target.value))
                }
                type="number"
                value={trainingPercentage}
              />
            </label>
            <button className="button button--small button--outline" disabled={busy} type="submit">
              Save progress
            </button>
          </form>
        )}
        {application.status === 'ASSESSMENT' && (
          <>
            <button
              className="button button--small button--outline"
              disabled={busy}
              onClick={() => void onAssessment(application.id, 'PASSED')}
              type="button"
            >
              Record pass
            </button>
            <button
              className="button button--small button--outline"
              disabled={busy}
              onClick={() => void onAssessment(application.id, 'FAILED')}
              type="button"
            >
              Record fail
            </button>
          </>
        )}
        {application.status === 'READY_FOR_MATCHING' && availableRequests.length > 0 && (
          <div className="dashboard-inline-form">
            <label>
              Active matching request
              <select
                onChange={(event) => onSelectRequest(application.id, event.target.value)}
                value={selectedRequest}
              >
                <option value="">Choose a request</option>
                {availableRequests.map((request) => (
                  <option key={request.id} value={request.id}>
                    {request.companyName} · {roleName(request.roleNeeded)}
                  </option>
                ))}
              </select>
            </label>
            <button
              className="button button--small button--outline"
              disabled={busy || !selectedRequest}
              onClick={() => void onMatch(application.id)}
              type="button"
            >
              Authorize match
            </button>
          </div>
        )}
        {activeMatches.map((match) => (
          <button
            className="button button--small button--outline"
            disabled={busy}
            key={match.id}
            onClick={() => void onPlace(application.id, match.hiringRequestId)}
            type="button"
          >
            Confirm placement · {match.hiringRequest.companyName}
          </button>
        ))}
      </div>
    </article>
  )
}
