import express from 'express'
import type { PrismaClient } from '@prisma/client'
import { hash } from 'bcryptjs'
import request from 'supertest'
import { describe, expect, it, vi } from 'vitest'
import { errorHandler } from '../http.js'
import { createAuthRouter } from './auth.js'

function createAuthApp(user: unknown) {
  const prisma = {
    user: {
      findUnique: vi.fn().mockResolvedValue(user),
    },
    refreshSession: {
      create: vi.fn().mockResolvedValue({}),
    },
  } as unknown as PrismaClient
  const app = express()
  app.use(express.json())
  app.use('/auth', createAuthRouter(prisma))
  app.use(errorHandler)
  return app
}

describe('authentication routes', () => {
  it('issues a short-lived access token and HttpOnly refresh cookie without exposing the hash', async () => {
    const passwordHash = await hash('a-valid-test-password', 4)
    const app = createAuthApp({
      id: '00000000-0000-4000-8000-000000000001',
      email: 'ada@example.com',
      fullName: 'Ada Okafor',
      role: 'CANDIDATE',
      passwordHash,
    })

    const response = await request(app)
      .post('/auth/login')
      .send({ email: 'ADA@example.com', password: 'a-valid-test-password' })
      .expect(200)

    expect(response.body.data.accessToken).toBeTruthy()
    expect(response.body.data.expiresIn).toBeLessThanOrEqual(900)
    expect(response.body.data.user).toEqual({
      id: '00000000-0000-4000-8000-000000000001',
      email: 'ada@example.com',
      fullName: 'Ada Okafor',
      role: 'CANDIDATE',
    })
    expect(JSON.stringify(response.body)).not.toContain('passwordHash')
    expect(response.headers['set-cookie'][0]).toContain('HttpOnly')
    expect(response.headers['set-cookie'][0]).toContain('SameSite=Strict')
    expect(response.headers['set-cookie'][0]).toContain('/api/v1/auth')
  })

  it('uses the same credential error for an unknown email and a bad password', async () => {
    const app = createAuthApp(null)
    const response = await request(app)
      .post('/auth/login')
      .send({ email: 'missing@example.com', password: 'a-valid-test-password' })
      .expect(401)

    expect(response.body).toEqual({
      error: { code: 'INVALID_CREDENTIALS', message: 'Email or password is incorrect.' },
    })
  })
})
